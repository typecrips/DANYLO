# Portfolio (static)

Static HTML/CSS/JS site ready for GitHub Pages.

## Run locally
Just open `index.html` in a browser (or use a tiny server):

```bash
python3 -m http.server 5173
```

Then open: http://localhost:5173

## Deploy to GitHub Pages
1. Create a repo
2. Commit all files
3. GitHub → Settings → Pages → Deploy from branch → `main` / `/root`
